import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  base: '/Trending-Motion-Agency/', // CRITICAL: Matches your repository name for GH Pages
})